--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.2
-- Dumped by pg_dump version 16.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE policia;
--
-- Name: policia; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE policia WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'Portuguese_Brazil.1252';


ALTER DATABASE policia OWNER TO postgres;

\connect policia

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: pg_database_owner
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO pg_database_owner;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: pg_database_owner
--

COMMENT ON SCHEMA public IS 'standard public schema';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: delegacia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.delegacia (
    del_se_id integer NOT NULL,
    del_int_num_policiais integer NOT NULL,
    del_int_num_processos integer NOT NULL,
    del_fk_end integer NOT NULL
);


ALTER TABLE public.delegacia OWNER TO postgres;

--
-- Name: delegacia_del_se_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.delegacia_del_se_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.delegacia_del_se_id_seq OWNER TO postgres;

--
-- Name: delegacia_del_se_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.delegacia_del_se_id_seq OWNED BY public.delegacia.del_se_id;


--
-- Name: denuncia; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.denuncia (
    den_se_id integer NOT NULL,
    den_dt_data date NOT NULL,
    den_tx_detalhamento character varying(255) NOT NULL,
    den_bl_anonimo boolean,
    den_fk_sec integer NOT NULL,
    den_fk_usu integer NOT NULL,
    den_fk_end integer
);


ALTER TABLE public.denuncia OWNER TO postgres;

--
-- Name: denuncia_den_se_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.denuncia_den_se_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.denuncia_den_se_id_seq OWNER TO postgres;

--
-- Name: denuncia_den_se_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.denuncia_den_se_id_seq OWNED BY public.denuncia.den_se_id;


--
-- Name: endereco; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.endereco (
    end_se_id integer NOT NULL,
    end_int_cep integer NOT NULL,
    end_tx_logradouro character varying(255) NOT NULL,
    end_tx_bairro character varying(50) NOT NULL,
    end_tx_uf character varying(2) NOT NULL,
    end_int_numero integer,
    end_tx_complemento character varying(25),
    end_tx_referencia character varying(50)
);


ALTER TABLE public.endereco OWNER TO postgres;

--
-- Name: endereco_end_se_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.endereco_end_se_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.endereco_end_se_id_seq OWNER TO postgres;

--
-- Name: endereco_end_se_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.endereco_end_se_id_seq OWNED BY public.endereco.end_se_id;


--
-- Name: policial; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.policial (
    pol_se_id integer NOT NULL,
    pol_tx_telefone character varying(11) NOT NULL,
    pol_tx_nome character varying(50) NOT NULL,
    pol_tx_cpf character varying(11) NOT NULL,
    pol_fk_end integer NOT NULL,
    pol_fk_sec integer NOT NULL
);


ALTER TABLE public.policial OWNER TO postgres;

--
-- Name: policial_pol_se_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.policial_pol_se_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.policial_pol_se_id_seq OWNER TO postgres;

--
-- Name: policial_pol_se_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.policial_pol_se_id_seq OWNED BY public.policial.pol_se_id;


--
-- Name: processo; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.processo (
    pro_se_id integer NOT NULL,
    pro_tx_detalhamento character varying(255) NOT NULL,
    pro_bl_ativo boolean NOT NULL,
    pro_fk_den integer NOT NULL,
    pro_fk_pol integer NOT NULL,
    pro_fk_sec integer NOT NULL
);


ALTER TABLE public.processo OWNER TO postgres;

--
-- Name: processo_pro_se_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.processo_pro_se_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.processo_pro_se_id_seq OWNER TO postgres;

--
-- Name: processo_pro_se_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.processo_pro_se_id_seq OWNED BY public.processo.pro_se_id;


--
-- Name: secao; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.secao (
    sec_se_id integer NOT NULL,
    sec_tx_cat character varying(30) NOT NULL,
    sec_int_num_processos integer NOT NULL,
    sec_fk_del integer NOT NULL
);


ALTER TABLE public.secao OWNER TO postgres;

--
-- Name: secao_sec_se_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.secao_sec_se_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.secao_sec_se_id_seq OWNER TO postgres;

--
-- Name: secao_sec_se_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.secao_sec_se_id_seq OWNED BY public.secao.sec_se_id;


--
-- Name: usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.usuario (
    usu_se_id integer NOT NULL,
    usu_tx_nome character varying(50) NOT NULL,
    usu_tx_email character varying(50) NOT NULL,
    usu_tx_telefone character varying(11) NOT NULL,
    usu_tx_cpf character varying(11) NOT NULL,
    usu_tx_genero character varying(20) NOT NULL,
    usu_fk_end integer NOT NULL
);


ALTER TABLE public.usuario OWNER TO postgres;

--
-- Name: usuario_usu_se_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.usuario_usu_se_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.usuario_usu_se_id_seq OWNER TO postgres;

--
-- Name: usuario_usu_se_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.usuario_usu_se_id_seq OWNED BY public.usuario.usu_se_id;


--
-- Name: delegacia del_se_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delegacia ALTER COLUMN del_se_id SET DEFAULT nextval('public.delegacia_del_se_id_seq'::regclass);


--
-- Name: denuncia den_se_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.denuncia ALTER COLUMN den_se_id SET DEFAULT nextval('public.denuncia_den_se_id_seq'::regclass);


--
-- Name: endereco end_se_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco ALTER COLUMN end_se_id SET DEFAULT nextval('public.endereco_end_se_id_seq'::regclass);


--
-- Name: policial pol_se_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policial ALTER COLUMN pol_se_id SET DEFAULT nextval('public.policial_pol_se_id_seq'::regclass);


--
-- Name: processo pro_se_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processo ALTER COLUMN pro_se_id SET DEFAULT nextval('public.processo_pro_se_id_seq'::regclass);


--
-- Name: secao sec_se_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secao ALTER COLUMN sec_se_id SET DEFAULT nextval('public.secao_sec_se_id_seq'::regclass);


--
-- Name: usuario usu_se_id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario ALTER COLUMN usu_se_id SET DEFAULT nextval('public.usuario_usu_se_id_seq'::regclass);


--
-- Data for Name: delegacia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.delegacia (del_se_id, del_int_num_policiais, del_int_num_processos, del_fk_end) FROM stdin;
\.
COPY public.delegacia (del_se_id, del_int_num_policiais, del_int_num_processos, del_fk_end) FROM '$$PATH$$/4898.dat';

--
-- Data for Name: denuncia; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.denuncia (den_se_id, den_dt_data, den_tx_detalhamento, den_bl_anonimo, den_fk_sec, den_fk_usu, den_fk_end) FROM stdin;
\.
COPY public.denuncia (den_se_id, den_dt_data, den_tx_detalhamento, den_bl_anonimo, den_fk_sec, den_fk_usu, den_fk_end) FROM '$$PATH$$/4904.dat';

--
-- Data for Name: endereco; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.endereco (end_se_id, end_int_cep, end_tx_logradouro, end_tx_bairro, end_tx_uf, end_int_numero, end_tx_complemento, end_tx_referencia) FROM stdin;
\.
COPY public.endereco (end_se_id, end_int_cep, end_tx_logradouro, end_tx_bairro, end_tx_uf, end_int_numero, end_tx_complemento, end_tx_referencia) FROM '$$PATH$$/4894.dat';

--
-- Data for Name: policial; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.policial (pol_se_id, pol_tx_telefone, pol_tx_nome, pol_tx_cpf, pol_fk_end, pol_fk_sec) FROM stdin;
\.
COPY public.policial (pol_se_id, pol_tx_telefone, pol_tx_nome, pol_tx_cpf, pol_fk_end, pol_fk_sec) FROM '$$PATH$$/4902.dat';

--
-- Data for Name: processo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.processo (pro_se_id, pro_tx_detalhamento, pro_bl_ativo, pro_fk_den, pro_fk_pol, pro_fk_sec) FROM stdin;
\.
COPY public.processo (pro_se_id, pro_tx_detalhamento, pro_bl_ativo, pro_fk_den, pro_fk_pol, pro_fk_sec) FROM '$$PATH$$/4906.dat';

--
-- Data for Name: secao; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.secao (sec_se_id, sec_tx_cat, sec_int_num_processos, sec_fk_del) FROM stdin;
\.
COPY public.secao (sec_se_id, sec_tx_cat, sec_int_num_processos, sec_fk_del) FROM '$$PATH$$/4900.dat';

--
-- Data for Name: usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.usuario (usu_se_id, usu_tx_nome, usu_tx_email, usu_tx_telefone, usu_tx_cpf, usu_tx_genero, usu_fk_end) FROM stdin;
\.
COPY public.usuario (usu_se_id, usu_tx_nome, usu_tx_email, usu_tx_telefone, usu_tx_cpf, usu_tx_genero, usu_fk_end) FROM '$$PATH$$/4896.dat';

--
-- Name: delegacia_del_se_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.delegacia_del_se_id_seq', 5, true);


--
-- Name: denuncia_den_se_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.denuncia_den_se_id_seq', 5, true);


--
-- Name: endereco_end_se_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.endereco_end_se_id_seq', 20, true);


--
-- Name: policial_pol_se_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.policial_pol_se_id_seq', 5, true);


--
-- Name: processo_pro_se_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.processo_pro_se_id_seq', 5, true);


--
-- Name: secao_sec_se_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.secao_sec_se_id_seq', 5, true);


--
-- Name: usuario_usu_se_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.usuario_usu_se_id_seq', 5, true);


--
-- Name: delegacia delegacia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delegacia
    ADD CONSTRAINT delegacia_pkey PRIMARY KEY (del_se_id);


--
-- Name: denuncia denuncia_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.denuncia
    ADD CONSTRAINT denuncia_pkey PRIMARY KEY (den_se_id);


--
-- Name: endereco endereco_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.endereco
    ADD CONSTRAINT endereco_pkey PRIMARY KEY (end_se_id);


--
-- Name: policial policial_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policial
    ADD CONSTRAINT policial_pkey PRIMARY KEY (pol_se_id);


--
-- Name: processo processo_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processo
    ADD CONSTRAINT processo_pkey PRIMARY KEY (pro_se_id);


--
-- Name: secao secao_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secao
    ADD CONSTRAINT secao_pkey PRIMARY KEY (sec_se_id);


--
-- Name: usuario usuario_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_pkey PRIMARY KEY (usu_se_id);


--
-- Name: delegacia delegacia_del_fk_end_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.delegacia
    ADD CONSTRAINT delegacia_del_fk_end_fkey FOREIGN KEY (del_fk_end) REFERENCES public.endereco(end_se_id);


--
-- Name: denuncia denuncia_den_fk_end_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.denuncia
    ADD CONSTRAINT denuncia_den_fk_end_fkey FOREIGN KEY (den_fk_end) REFERENCES public.endereco(end_se_id);


--
-- Name: denuncia denuncia_den_fk_sec_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.denuncia
    ADD CONSTRAINT denuncia_den_fk_sec_fkey FOREIGN KEY (den_fk_sec) REFERENCES public.secao(sec_se_id);


--
-- Name: denuncia denuncia_den_fk_usu_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.denuncia
    ADD CONSTRAINT denuncia_den_fk_usu_fkey FOREIGN KEY (den_fk_usu) REFERENCES public.usuario(usu_se_id);


--
-- Name: policial policial_pol_fk_end_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policial
    ADD CONSTRAINT policial_pol_fk_end_fkey FOREIGN KEY (pol_fk_end) REFERENCES public.endereco(end_se_id);


--
-- Name: policial policial_pol_fk_sec_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.policial
    ADD CONSTRAINT policial_pol_fk_sec_fkey FOREIGN KEY (pol_fk_sec) REFERENCES public.secao(sec_se_id);


--
-- Name: processo processo_pro_fk_den_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processo
    ADD CONSTRAINT processo_pro_fk_den_fkey FOREIGN KEY (pro_fk_den) REFERENCES public.denuncia(den_se_id);


--
-- Name: processo processo_pro_fk_pol_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processo
    ADD CONSTRAINT processo_pro_fk_pol_fkey FOREIGN KEY (pro_fk_pol) REFERENCES public.policial(pol_se_id);


--
-- Name: processo processo_pro_fk_sec_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.processo
    ADD CONSTRAINT processo_pro_fk_sec_fkey FOREIGN KEY (pro_fk_sec) REFERENCES public.secao(sec_se_id);


--
-- Name: secao secao_sec_fk_del_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.secao
    ADD CONSTRAINT secao_sec_fk_del_fkey FOREIGN KEY (sec_fk_del) REFERENCES public.delegacia(del_se_id);


--
-- Name: usuario usuario_usu_fk_end_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.usuario
    ADD CONSTRAINT usuario_usu_fk_end_fkey FOREIGN KEY (usu_fk_end) REFERENCES public.endereco(end_se_id);


--
-- PostgreSQL database dump complete
--

